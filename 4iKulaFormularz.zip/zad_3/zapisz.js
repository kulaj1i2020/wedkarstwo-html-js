imie=document.querySelector("#imie")
nazwisko=document.querySelector("#nazwisko")
adres=document.querySelector("#adres")
form=document.querySelector("form")
display1=document.querySelector(".display1")
// submit=document.querySelector("#submit")
// reset=document.querySelector("#reset")

form.addEventListener('submit',evt => {
    evt.preventDefault();
    let elem= document.createElement(`p`);
    elem.innerHTML += `Imie: ${imie.value} , Nazwisko: ${nazwisko.value} , adres: ${adres.value}`
    display1.appendChild(elem);
})
